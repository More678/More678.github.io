/*
 Navicat Premium Data Transfer

 Source Server         : phpstudy
 Source Server Type    : MySQL
 Source Server Version : 50726
 Source Host           : localhost:3306
 Source Schema         : test

 Target Server Type    : MySQL
 Target Server Version : 50726
 File Encoding         : 65001

 Date: 29/07/2025 10:45:04
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for user_verification
-- ----------------------------
DROP TABLE IF EXISTS `user_verification`;
CREATE TABLE `user_verification`  (
  `uid` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '用户ID',
  `introducer` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '介绍人ID',
  `phone_number` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `verification` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '会员介绍关系图' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of user_verification
-- ----------------------------
INSERT INTO `user_verification` VALUES (23, 0, '133****9804', 'GQZTSMZZGI4DANG');
INSERT INTO `user_verification` VALUES (24, 7, '147****0892', 'GQZTSMZZGQ4DSMC');
INSERT INTO `user_verification` VALUES (25, 11, '143****1751', 'GQZTSMZZGI3TKMB');
INSERT INTO `user_verification` VALUES (26, 18, '143****4348', 'GQZTSMZZGQZTIOF');
INSERT INTO `user_verification` VALUES (27, 23, '143****1976', 'GQZTSMZZGE4TONH');
INSERT INTO `user_verification` VALUES (28, 15, '143****8056', 'GQZTSMZZHAYDKND');
INSERT INTO `user_verification` VALUES (29, 11, '143****3814', 'GQZTSMZZGM4DCNF');
INSERT INTO `user_verification` VALUES (30, 26, '143****3900', 'GQZTSMZZGM4TAMG');
INSERT INTO `user_verification` VALUES (31, 13, '143****5606', 'GQZTSMZZGU3DANG');
INSERT INTO `user_verification` VALUES (32, 27, '133****9804', 'GQZTSMZZGMYTKNH');
INSERT INTO `user_verification` VALUES (33, 17, '147****3122', 'GQZTSMZZGMYTEMB');
INSERT INTO `user_verification` VALUES (34, 17, '133****9804', 'GQZTSMZZGY4DGNF');
INSERT INTO `user_verification` VALUES (35, 12, '143****5838', 'GQZTSMZZGU4DGOE');
INSERT INTO `user_verification` VALUES (36, 35, '143****5911', 'GQZTSMZZGU4TCMD');
INSERT INTO `user_verification` VALUES (37, 18, '143****4363', 'GQZTSMZZGQZTMMD');
INSERT INTO `user_verification` VALUES (38, 17, '143****5638', 'GQZTSMZZGU3DGOG');
INSERT INTO `user_verification` VALUES (39, 30, '143****4343', 'GQZTSMZZGQZTIMG');
INSERT INTO `user_verification` VALUES (40, 27, '143****2474', 'GQZTSMZZGI2DONA');
INSERT INTO `user_verification` VALUES (41, 36, '143****7079', 'GQZTSMZZG4YDOOF');
INSERT INTO `user_verification` VALUES (42, 27, '143****1348', 'GQZTSMZZGEZTIOE');
INSERT INTO `user_verification` VALUES (43, 21, '143****6453', 'GQZTSMZZGY2DKME');
INSERT INTO `user_verification` VALUES (44, 43, '143****5140', 'GQZTSMZZGUYTIMB');
INSERT INTO `user_verification` VALUES (45, 22, '143****3535', 'GQZTSMZZGM2TGNG');
INSERT INTO `user_verification` VALUES (46, 28, '143****7115', 'GQZTSMZZG4YTCNE');
INSERT INTO `user_verification` VALUES (47, 39, '143****6101', 'GQZTSMZZGYYTAMD');
INSERT INTO `user_verification` VALUES (48, 34, '143****5475', 'GQZTSMZZGU2DONB');
INSERT INTO `user_verification` VALUES (49, 38, '143****4103', 'GQZTSMZZGQYTAMA');
INSERT INTO `user_verification` VALUES (50, 33, '143****7008', 'GQZTSMZZG4YDAOG');
INSERT INTO `user_verification` VALUES (51, 44, '143****1863', 'GQZTSMZZGE4DMMA');
INSERT INTO `user_verification` VALUES (52, 48, '143****8468', 'GQZTSMZZHA2DMOB');
INSERT INTO `user_verification` VALUES (53, 33, '143****2128', 'GQZTSMZZGIYTEOE');
INSERT INTO `user_verification` VALUES (54, 49, '143****7566', 'GQZTSMZZG42TMNE');
INSERT INTO `user_verification` VALUES (55, 53, '143****1738', 'GQZTSMZZGE3TGOD');
INSERT INTO `user_verification` VALUES (56, 50, '143****4373', 'GQZTSMZZGQZTOMC');
INSERT INTO `user_verification` VALUES (57, 39, '143****2122', 'GQZTSMZZGIYTEME');
INSERT INTO `user_verification` VALUES (58, 47, '143****5089', 'GQZTSMZZGUYDQOG');
INSERT INTO `user_verification` VALUES (59, 56, '143****2487', 'GQZTSMZZGI2DQNA');
INSERT INTO `user_verification` VALUES (60, 47, '143****5991', 'GQZTSMZZGU4TSMB');
INSERT INTO `user_verification` VALUES (61, 42, '143****6976', 'GQZTSMZZGY4TONF');
INSERT INTO `user_verification` VALUES (62, 39, '143****3268', 'GQZTSMZZGMZDMOG');
INSERT INTO `user_verification` VALUES (63, 60, '143****5221', 'GQZTSMZZGUZDEMD');
INSERT INTO `user_verification` VALUES (64, 63, '143****5527', 'GQZTSMZZGU2TENA');
INSERT INTO `user_verification` VALUES (65, 45, '143****2569', 'GQZTSMZZGI2TMOA');
INSERT INTO `user_verification` VALUES (66, 52, '143****8454', 'GQZTSMZZHA2DKNG');
INSERT INTO `user_verification` VALUES (67, 66, '143****5441', 'GQZTSMZZGU2DIMH');
INSERT INTO `user_verification` VALUES (68, 47, '143****5972', 'GQZTSMZZGU4TOMB');
INSERT INTO `user_verification` VALUES (69, 57, '143****3830', 'GQZTSMZZGM4DGMD');
INSERT INTO `user_verification` VALUES (70, 68, '143****3046', 'GQZTSMZZGMYDINC');
INSERT INTO `user_verification` VALUES (71, 64, '143****1806', 'GQZTSMZZGE4DANG');
INSERT INTO `user_verification` VALUES (72, 56, '143****2188', 'GQZTSMZZGIYTQOE');
INSERT INTO `user_verification` VALUES (73, 58, '143****5805', 'GQZTSMZZGU4DANF');
INSERT INTO `user_verification` VALUES (74, 63, '143****3880', 'GQZTSMZZGM4DQME');
INSERT INTO `user_verification` VALUES (75, 57, '143****4532', 'GQZTSMZZGQ2TGME');
INSERT INTO `user_verification` VALUES (76, 61, '143****3749', 'GQZTSMZZGM3TIOB');
INSERT INTO `user_verification` VALUES (77, 59, '143****8624', 'GQZTSMZZHA3DENG');
INSERT INTO `user_verification` VALUES (78, 56, '143****3119', 'GQZTSMZZGMYTCOE');
INSERT INTO `user_verification` VALUES (79, 66, '143****6417', 'GQZTSMZZGY2DCND');
INSERT INTO `user_verification` VALUES (80, 78, '143****6936', 'GQZTSMZZGY4TGNB');
INSERT INTO `user_verification` VALUES (81, 67, '143****8679', 'GQZTSMZZHA3DOOA');
INSERT INTO `user_verification` VALUES (82, 66, '143****6840', 'GQZTSMZZGY4DIMG');
INSERT INTO `user_verification` VALUES (83, 71, '143****2982', 'GQZTSMZZGI4TQMH');

SET FOREIGN_KEY_CHECKS = 1;
